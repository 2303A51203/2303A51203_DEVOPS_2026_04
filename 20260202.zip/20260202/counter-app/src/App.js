import logo from './logo.svg';
import './App.css';
import { useState } from 'react';

function App() {
  const [count,setCount] = useState(0);
  const decrementCount = ()=>{
    if(count>0){
      setCount(count-1);
    }
  }

  const incrementCount = ()=>{
    if(count>=10){
      alert("Count cannot be more than 10");
      return;
    }
    setCount(count+1);
  }

  return (
    <div className="App">
      <header>Count : {count}</header>
      <button onClick={()=>incrementCount()}>increment</button>
      <button onClick={()=>decrementCount()}>decrement</button>
      <button onClick={()=>setCount(0)}>reset</button>
    </div>
  );
}

export default App;
